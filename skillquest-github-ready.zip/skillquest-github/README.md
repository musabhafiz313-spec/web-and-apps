# SKILLQUEST
বাংলা-ভিত্তিক শেখার প্ল্যাটফর্ম: KNOW → WRITE → THINK → DO.

## এই রিপোজিটরিতে যা আছে
- Next.js 15 + TypeScript ভিত্তিক ওয়েব অ্যাপ
- বাংলা responsive landing page ও 3D-inspired orbital hero
- KNOW, WRITE, THINK, DO আলাদা পেজ
- নিবন্ধন ও লগইন UI; Supabase Auth সংযোগের প্রাথমিক কোড
- Dashboard ও Admin navigation scaffold
- Supabase-এর প্রাথমিক SQL schema

## GitHub-এ আপলোড
1. ZIP extract করে সব ফাইল GitHub repository-তে upload করুন (অথবা GitHub Desktop দিয়ে folder publish করুন)।
2. GitHub repository-র root-এ `package.json`, `app/`, `supabase/` থাকতে হবে।
3. `.env.example` কপি করে `.env.local` নামে ফাইল তৈরি করুন এবং Supabase URL ও anon key বসান। `.env.local` কখনো GitHub-এ commit করবেন না।
4. Supabase SQL Editor-এ `supabase/schema.sql` চালান।
5. Vercel-এ GitHub repository import করে একই environment variables যোগ করে deploy করুন।

## স্থানীয়ভাবে চালাতে
Node.js 20.9+ প্রয়োজন।
```bash
npm install
npm run dev
```
তারপর http://localhost:3000 খুলুন।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
এটি GitHub-ready প্রাথমিক অ্যাপ ও ডেটাবেস schema; সম্পূর্ণ production competition engine নয়। Admin RBAC, server-side validation, email verification redirect, secure profile provisioning, Feather atomic ledger, daily scheduler, audited winner draw, referral/code-exchange reward RPC, file uploads, CMS publishing, fraud review এবং privacy/terms এখনও implement ও security-test করতে হবে। Admin পেজে এখনো বাস্তব admin authentication নেই—সাইট public deploy করার আগে সেটি বাধ্যতামূলক। Supabase service-role key কখনো browser/client code বা GitHub-এ দেবেন না।
