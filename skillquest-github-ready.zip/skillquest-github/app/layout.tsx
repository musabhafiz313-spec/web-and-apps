import type { Metadata } from 'next';
import './globals.css';
import Nav from '@/components/Nav';
export const metadata: Metadata = { title: 'SKILLQUEST — Knowing Isn’t Doing', description: 'জানো। লেখো। ভাবো। করে দেখাও।' };
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="bn"><body><Nav/>{children}<footer>© ২০২৬ SKILLQUEST · KNOWING ISN’T DOING.</footer></body></html>}
