-- SKILLQUEST initial database schema. Run in Supabase SQL Editor.
create extension if not exists pgcrypto;
create type public.challenge_type as enum ('know','write','think','do');
create type public.submission_status as enum ('pending','approved','rejected');
create table public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 full_name text not null,
 district text not null,
 member_code text unique not null default upper(substr(encode(gen_random_bytes(8),'hex'),1,10)),
 referral_code text,
 created_at timestamptz not null default now()
);
create table public.challenges (
 id uuid primary key default gen_random_uuid(),
 kind public.challenge_type not null,
 title text not null,
 description text not null default '',
 is_published boolean not null default false,
 starts_at timestamptz,
 ends_at timestamptz,
 created_at timestamptz not null default now()
);
create table public.submissions (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.profiles(id),
 challenge_id uuid not null references public.challenges(id),
 answer jsonb not null default '{}'::jsonb,
 status public.submission_status not null default 'pending',
 score numeric(8,2),
 submitted_at timestamptz not null default now(),
 reviewed_at timestamptz,
 unique(user_id,challenge_id)
);
create table public.feather_wallets (
 user_id uuid primary key references public.profiles(id) on delete cascade,
 balance integer not null default 0 check(balance >= 0),
 updated_at timestamptz not null default now()
);
create table public.feather_transactions (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.profiles(id),
 amount integer not null,
 reason text not null,
 reference_id uuid,
 created_at timestamptz not null default now()
);
create table public.code_exchanges (
 id uuid primary key default gen_random_uuid(),
 sender_id uuid not null references public.profiles(id),
 receiver_id uuid not null references public.profiles(id),
 created_at timestamptz not null default now(),
 check(sender_id <> receiver_id),
 unique(sender_id,receiver_id)
);
create table public.winners (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.profiles(id),
 challenge_date date not null,
 district text not null,
 created_at timestamptz not null default now(),
 unique(user_id,challenge_date)
);
-- Enable RLS. Policies must be added before exposing tables to client users.
alter table public.profiles enable row level security;
alter table public.challenges enable row level security;
alter table public.submissions enable row level security;
alter table public.feather_wallets enable row level security;
alter table public.feather_transactions enable row level security;
alter table public.code_exchanges enable row level security;
alter table public.winners enable row level security;
-- Minimal safe read policies; all writes should go through trusted server functions.
create policy "published challenges are readable" on public.challenges for select using (is_published = true);
create policy "users read own profile" on public.profiles for select using (auth.uid() = id);
create policy "users read own wallet" on public.feather_wallets for select using (auth.uid() = user_id);
create policy "users read own transactions" on public.feather_transactions for select using (auth.uid() = user_id);
create policy "users read own submissions" on public.submissions for select using (auth.uid() = user_id);
